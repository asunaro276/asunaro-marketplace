# プロジェクト規約 - HTML/CSS/Vue

このドキュメントは、Figma デザインから HTML/CSS/Vue コードを実装する際の
プロジェクト固有の規約とベストプラクティスを定義します。

## 必須: これらの規約に厳密に従うこと

以下の規約は **必ず遵守** してください。一貫性のあるコードベースを維持するために重要です。

---

## 1. ファイル命名規則

### Vue コンポーネント
- **ファイル名**: PascalCase を使用
  ```
  ✓ ButtonPrimary.vue
  ✓ UserProfileCard.vue
  ✗ button-primary.vue
  ✗ userProfileCard.vue
  ```

### CSS/SCSS ファイル
- **ファイル名**: kebab-case を使用
  ```
  ✓ button-styles.css
  ✓ user-profile.scss
  ✗ ButtonStyles.css
  ✗ user_profile.scss
  ```

---

## 2. CSS クラス命名規則

### BEM (Block Element Modifier) を使用

**構造:**
```
.block__element--modifier
```

**例:**
```css
/* ブロック */
.button { }

/* エレメント */
.button__icon { }
.button__text { }

/* モディファイア */
.button--primary { }
.button--large { }
.button--disabled { }

/* 組み合わせ */
.button__icon--left { }
```

**実装例:**
```html
<!-- ✓ 正しい -->
<button class="button button--primary button--large">
  <span class="button__icon button__icon--left">→</span>
  <span class="button__text">送信</span>
</button>

<!-- ✗ 間違い -->
<button class="btn primary large">
  <span class="icon left">→</span>
  <span class="text">送信</span>
</button>
```

### ユーティリティクラスの禁止

- **Tailwind CSS を使用しない場合**、ユーティリティクラス（`.mt-4`, `.flex` など）は使用禁止
- 代わりに BEM に従ったセマンティックなクラス名を使用

```css
/* ✓ 正しい */
.card__header {
  display: flex;
  margin-top: 16px;
}

/* ✗ 間違い（Tailwind を使わない場合）*/
<div class="flex mt-4">
```

---

## 3. CSS カスタムプロパティ（CSS変数）の使用

### デザイントークンは必ず CSS 変数として定義

**配置場所:** `styles/tokens.css` または `styles/_variables.scss`

```css
/* tokens.css */
:root {
  /* カラー */
  --color-primary: #3B82F6;
  --color-secondary: #10B981;
  --color-text-primary: #1F2937;
  --color-text-secondary: #6B7280;
  --color-background: #FFFFFF;
  --color-surface: #F9FAFB;

  /* スペーシング */
  --spacing-xs: 4px;
  --spacing-sm: 8px;
  --spacing-md: 16px;
  --spacing-lg: 24px;
  --spacing-xl: 32px;

  /* タイポグラフィ */
  --font-family-primary: 'Inter', sans-serif;
  --font-size-sm: 14px;
  --font-size-base: 16px;
  --font-size-lg: 18px;
  --font-size-xl: 24px;
  --font-weight-normal: 400;
  --font-weight-medium: 500;
  --font-weight-bold: 700;

  /* ボーダー */
  --border-radius-sm: 4px;
  --border-radius-md: 8px;
  --border-radius-lg: 12px;

  /* シャドウ */
  --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
  --shadow-md: 0 4px 6px rgba(0, 0, 0, 0.1);
  --shadow-lg: 0 10px 15px rgba(0, 0, 0, 0.1);
}
```

### CSS 変数の使用

```css
/* ✓ 正しい */
.button {
  background-color: var(--color-primary);
  padding: var(--spacing-md);
  border-radius: var(--border-radius-md);
  font-family: var(--font-family-primary);
}

/* ✗ 間違い - ハードコードされた値 */
.button {
  background-color: #3B82F6;
  padding: 16px;
  border-radius: 8px;
  font-family: 'Inter', sans-serif;
}
```

---

## 4. Vue コンポーネント構造

### 単一ファイルコンポーネント (SFC) の順序

```vue
<template>
  <!-- HTML マークアップ -->
</template>

<script setup lang="ts">
// TypeScript コード
</script>

<style scoped>
/* コンポーネント固有のスタイル */
</style>
```

### テンプレート規約

```vue
<template>
  <!-- ✓ 正しい: ルート要素は1つ -->
  <div class="user-profile">
    <div class="user-profile__header">
      <h2 class="user-profile__name">{{ name }}</h2>
    </div>
    <div class="user-profile__content">
      <p class="user-profile__bio">{{ bio }}</p>
    </div>
  </div>

  <!-- ✗ 間違い: 複数のルート要素 -->
  <div class="user-profile__header">...</div>
  <div class="user-profile__content">...</div>
</template>
```

### Props の型定義

```vue
<script setup lang="ts">
// ✓ 正しい: TypeScript で型を定義
interface Props {
  name: string
  age?: number
  isActive: boolean
}

const props = defineProps<Props>()

// または
const props = defineProps({
  name: {
    type: String,
    required: true
  },
  age: {
    type: Number,
    default: 0
  }
})
</script>
```

---

## 5. スタイリング規約

### Scoped CSS の使用

- **必ず** `<style scoped>` を使用してコンポーネントスタイルを隔離
- グローバルスタイルは `styles/global.css` にのみ配置

```vue
<!-- ✓ 正しい -->
<style scoped>
.button {
  /* このスタイルはこのコンポーネント内でのみ有効 */
}
</style>

<!-- ✗ 間違い: scoped なし -->
<style>
.button {
  /* グローバルに影響してしまう */
}
</style>
```

### レスポンシブデザイン

**ブレークポイント定義:**
```css
:root {
  --breakpoint-sm: 640px;
  --breakpoint-md: 768px;
  --breakpoint-lg: 1024px;
  --breakpoint-xl: 1280px;
}
```

**メディアクエリの記述:**
```css
/* モバイルファースト */
.container {
  padding: var(--spacing-md);
}

/* タブレット以上 */
@media (min-width: 768px) {
  .container {
    padding: var(--spacing-lg);
  }
}

/* デスクトップ以上 */
@media (min-width: 1024px) {
  .container {
    padding: var(--spacing-xl);
  }
}
```

---

## 6. アクセシビリティ

### 必須要件

1. **セマンティック HTML を使用**
   ```html
   <!-- ✓ 正しい -->
   <button class="button button--primary">クリック</button>
   <nav class="navigation">...</nav>
   <main class="main-content">...</main>

   <!-- ✗ 間違い -->
   <div class="button" onclick="...">クリック</div>
   <div class="navigation">...</div>
   <div class="main-content">...</div>
   ```

2. **ARIA 属性の適切な使用**
   ```html
   <button
     class="button"
     aria-label="メニューを開く"
     aria-expanded="false"
   >
     メニュー
   </button>
   ```

3. **フォーカス可能な要素のスタイル**
   ```css
   .button:focus-visible {
     outline: 2px solid var(--color-primary);
     outline-offset: 2px;
   }
   ```

---

## 7. パフォーマンス

### CSS の最適化

1. **不要な詳細度を避ける**
   ```css
   /* ✓ 正しい */
   .button--primary { }

   /* ✗ 間違い - 過度な詳細度 */
   div.container > ul.list > li.item > button.button--primary { }
   ```

2. **高コストなプロパティの使用を最小限に**
   ```css
   /* 使用を避ける: box-shadow の複雑な値 */
   /* 代わりに CSS 変数で定義 */
   .card {
     box-shadow: var(--shadow-md);
   }
   ```

---

## 8. コメント規約

### CSS コメント

```css
/* ==========================================================================
   コンポーネント: Button
   ========================================================================== */

/**
 * プライマリボタン
 * 主要なアクションに使用
 */
.button--primary {
  background-color: var(--color-primary);
}

/* 状態: ホバー */
.button--primary:hover {
  background-color: var(--color-primary-dark);
}
```

### Vue コンポーネントコメント

```vue
<script setup lang="ts">
/**
 * ユーザープロフィールカード
 *
 * Figma: https://www.figma.com/file/...
 * 更新日: 2024-01-15
 */

// Props 定義
interface Props {
  /** ユーザー名 */
  name: string
  /** プロフィール画像URL */
  avatarUrl?: string
}
</script>
```

---

## 9. Figma からの実装フロー

### ステップ

1. **デザイントークンの抽出**
   - `get_variable_defs` でトークンを取得
   - `design_tokens_to_css.py` で CSS 変数に変換
   - `styles/tokens.css` に保存

2. **スクリーンショットの取得**
   - `get_screenshot` でデザインの視覚的リファレンスを取得

3. **コードの生成**
   - `get_design_context` で初期コードを生成
   - Vue + CSS に変換（必要に応じて）

4. **コンポーネント構造の実装**
   - BEM 規約に従ってクラス名を定義
   - CSS 変数を使用してスタイルを実装
   - セマンティック HTML を使用

5. **検証**
   - スクリーンショットと比較して視覚的な一致を確認
   - レスポンシブデザインを確認
   - アクセシビリティを確認

---

## 10. 禁止事項

### 絶対に行わないこと

1. **インラインスタイルの使用**
   ```html
   <!-- ✗ 禁止 -->
   <div style="color: red; margin: 10px;">
   ```

2. **!important の乱用**
   ```css
   /* ✗ 避けるべき（デバッグ時のみ許可）*/
   .button {
     color: red !important;
   }
   ```

3. **グローバルスコープの汚染**
   ```css
   /* ✗ コンポーネント内でグローバルスタイルを定義しない */
   <style>
   div { margin: 0; }
   </style>
   ```

4. **ハードコードされた値**
   ```css
   /* ✗ CSS 変数を使用すべき */
   .button {
     padding: 16px;
     color: #3B82F6;
   }
   ```

---

## チェックリスト

実装完了前に以下を確認：

- [ ] BEM 命名規則に従っているか
- [ ] CSS 変数（デザイントークン）を使用しているか
- [ ] `<style scoped>` を使用しているか
- [ ] セマンティック HTML を使用しているか
- [ ] アクセシビリティ要件を満たしているか
- [ ] レスポンシブデザインを実装しているか
- [ ] インラインスタイルや !important を使用していないか
- [ ] Figma デザインと視覚的に一致しているか

---

**重要:** この規約から逸脱する場合は、必ず理由をコメントで説明すること。
